<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Dream Car Rental</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="<?= base_url(); ?>Assets/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Rubik&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= base_url(); ?>Assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>Assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?= base_url(); ?>Assets/css/style.css" rel="stylesheet">
</head>

<body>
    <?php $this->load->view('Header'); ?>

    <!-- Page Header Start -->
    <div class="container-fluid page-header">
        <h1 class="display-3 text-uppercase text-white mb-3">Car Detail</h1>
        <div class="d-inline-flex text-white">
            <h6 class="text-uppercase m-0"><a class="text-white" href="">Home</a></h6>
            <h6 class="text-body m-0 px-3">/</h6>
            <h6 class="text-uppercase text-body m-0">Car Detail</h6>
        </div>
    </div>
    <!-- Page Header Start -->

    <!-- Detail Start -->
    <div class="container-fluid pt-5">
        <div class="container pt-5">
            <div class="row">
                <?php foreach ($detail as $dt) : ?>
                    <div class="col-lg-8 mb-5">
                        <h1 class="display-4 text-uppercase mb-5"><?php echo $dt->merk ?></h1>
                        <div class="row mx-n2 mb-3">
                            <div class="col-md-3 col-6 px-2 pb-2">
                                <img class="img-fluid w-100" src="<?php echo base_url('assets/upload/' . $dt->gambar) ?>" alt="<?php echo $dt->merk ?>">
                            </div>
                        </div>
                        <p>
                            Nikmati liburan tak terlupakan dengan rental movil eksklusif dari kami!
                            Sewa mobil kami untuk perjalanan yang nyaman, bebas repot mencari transportasi umum.
                            Dengan beragam pilihan movil berkualitas tinggi dan harga yang terjangkau,
                            kami siap memenuhi semua kebutuhan perjalanan Anda.
                        </p>
                        <div class="row pt-2">
                            <div class="col-md-3 col-6 mb-2">
                                <span>Penyedia: <?php echo $dt->nama_rental ?><span>
                            </div>
                            <div class="col-md-3 col-6 mb-2">
                                <span>Tahun Produksi : <?php echo $dt->tahun ?></span>
                            </div>
                            <div class="col-md-3 col-6 mb-2">
                                <span>Nomer Plat : <?php echo $dt->no_plat ?></span>
                            </div>
                            <div class="col-md-3 col-6 mb-2">
                                <span>Warna : <?php echo $dt->warna ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mb-5">
                        <div class="bg-secondary p-5">
                            <h3 class="text-primary text-center mb-4">Check Availability</h3>
                            <div class="form-group">
                                <div class="date" id="date1" data-target-input="nearest">
                                    <input type="text" class="form-control p-4 datetimepicker-input" placeholder="--- Pilih Tanggal ---" data-target="#date1" data-toggle="datetimepicker" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="time" id="time1" data-target-input="nearest">
                                    <input type="text" class="form-control p-4 datetimepicker-input" placeholder="--- Pilih Jam ---" data-target="#time1" data-toggle="datetimepicker" />
                                </div>
                            </div>
                            <div class="form-group mb-0">
                                <a href="<?= site_url('Welcome/Car_List')  ?>" class="btn btn-primary btn-block" style="height: 50px;">Cari</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <!-- Detail End -->

    <!-- Related Car Start -->
    <div class="container-fluid pb-5">
        <div class="container pb-5">
            <h2 class="mb-4">Related Cars</h2>
            <div class="owl-carousel related-carousel position-relative" style="padding: 0 30px;">
                <?php foreach ($mobil as $mb) : ?>
                    <div class="rent-item">
                        <img class="img-fluid mb-4" src="<?php echo base_url('Assets/upload/' . $mb->gambar) ?>" alt="<?php echo $mb->merk ?>">
                        <h4 class="text-uppercase mb-4"><?php echo $mb->merk ?></h4>
                        <div class="d-flex justify-content-center mb-4">
                            <div class="px-2">
                                <span>
                                    <?php if ($mb->ac == '1') { ?>
                                        <a>AC</a>
                                    <?php } else { ?>
                                    <?php } ?>
                                </span>
                            </div>
                            <div class="px-2 border-left border-right">
                                <span>
                                    <?php if ($mb->supir == '1') { ?>
                                        <a>SUPIR</a>
                                    <?php } else { ?>
                                    <?php } ?>
                                </span>
                            </div>
                            <div class="px-2">
                                <span>
                                    <?php if ($mb->mp3_player == '1') { ?>
                                        <a>MP3 PLAYER</a>
                                    <?php } else { ?>
                                    <?php } ?>
                                </span>
                            </div>
                        </div>
                        <a class="btn btn-primary px-3" href="<?= site_url('Welcome/Car_Detail/') . $mb->id_mobil ?>">Rp. <?php echo number_format($mb->harga, 0, ',', '.') ?>/Hari</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <!-- Related Car End -->

    <?php $this->load->view('Footer'); ?>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/easing/easing.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/waypoints/waypoints.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?= base_url(); ?>Assets/js/main.js"></script>
</body>

</html>