<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Dream Car Rental</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="<?= base_url(); ?>Assets/<?= base_url(); ?>Assets/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Rubik&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= base_url(); ?>Assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>Assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?= base_url(); ?>Assets/css/style.css" rel="stylesheet">
</head>

<body>
    <?php $this->load->view('Header'); ?>

    <!-- Banner Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="bg-banner py-5 px-4 text-center">
                <span class="m-2"><?php echo $this->session->flashdata('pesan') ?></span>
                <div class="col-md-12" style="align-items: center;">
                    <div class="contact-form mb-4" style="padding: 30px;">
                        <form action="<?= site_url('Auth/login') ?>" method="post">
                            <div class="row">
                                <div class="col-6 form-group">
                                    <label for="username">Username</label>
                                    <input id="username" type="text" class="form-control" name="username" tabindex="1" autofocus>
                                    <?php echo form_error('username', '<div class="text-small text-danger">', '</div>') ?>
                                </div>
                                <div class="col-6 form-group">
                                    <div class="d-block">
                                        <label for="password" class="control-label">Password</label>
                                    </div>
                                    <input id="password" type="password" class="form-control" name="password" tabindex="2"> <?php echo form_error('password', '<div class="text-small text-danger">', '</div>') ?>
                                </div>
                            </div>
                            <div>
                                <button class="btn btn-primary py-3 px-5" type="submit">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner End -->

    <?php $this->load->view('Footer'); ?>

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/easing/easing.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/waypoints/waypoints.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?= base_url(); ?>Assets/js/main.js"></script>
</body>

</html>