<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Dream Car Rental</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="<?= base_url(); ?>Assets/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Rubik&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= base_url(); ?>Assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>Assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?= base_url(); ?>Assets/css/style.css" rel="stylesheet">
</head>

<body>
    <?php $this->load->view('templates_customer/header'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header">
        <h1 class="display-3 text-uppercase text-white mb-3">Car Listing</h1>
        <div class="d-inline-flex text-white">
            <h6 class="text-uppercase m-0"><a class="text-white" href="">Home</a></h6>
            <h6 class="text-body m-0 px-3">/</h6>
            <h6 class="text-uppercase text-body m-0">Car Listing</h6>
        </div>
    </div>
    <!-- Page Header Start -->


    <!-- Rent A Car Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <h1 class="display-4 text-uppercase text-center mb-5">Find Your Car</h1>
            <div class="row">
                <?php foreach ($mobil as $mb) : ?>
                    <div class="col-lg-4 col-md-6 mb-2">
                        <div class="rent-item mb-4">
                            <img class="img-fluid mb-4" src="<?php echo base_url('assets/upload/' . $mb->gambar) ?>" alt="<?php echo $mb->merk ?>">
                            <h4 class="text-uppercase mb-4"><?php echo $mb->merk ?></h4>
                            <div class="d-flex justify-content-center mb-4">
                                <div class="px-2">
                                    <span> <?php if ($mb->ac == '1') { ?>
                                            <a>AC</a>
                                        <?php } else { ?>
                                        <?php } ?>
                                    </span>
                                </div>
                                <div class="px-2">
                                    <span>
                                        <?php if ($mb->supir == '1') { ?>
                                            <a>SUPIR</a>
                                        <?php } else { ?>
                                        <?php } ?>
                                    </span>
                                </div>

                                <div class="px-2">
                                    <span>
                                        <?php if ($mb->mp3_player == '1') { ?>
                                            <a>MP3 PLAYER</a>
                                        <?php } else { ?>
                                        <?php } ?>
                                    </span>
                                </div>

                                <div class="px-2">
                                    <span>
                                        <?php if ($mb->central_lock == '1') { ?>
                                            <a>CENTRAL LOCK</a>
                                        <?php } else { ?>
                                        <?php } ?>
                                    </span>
                                </div>
                            </div>
                            <a class="btn btn-primary px-3" href="<?= site_url('Welcome/Car_Detail/') . $mb->id_mobil ?>">Rp. <?php echo number_format($mb->harga, 0, ',', '.') ?>/Hari</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <!-- Rent A Car End -->

    <!-- Banner Start -->
    <div class="container-fluid py-5">
        <div class="container py-5">
            <div class="row mx-0">
                <div class="col-lg-6 px-0">
                    <div class="px-5 bg-secondary d-flex align-items-center justify-content-between" style="height: 350px;">
                        <img class="img-fluid flex-shrink-0 ml-n5 w-50 mr-4" src="<?= base_url(); ?>Assets/img/banner-left.png" alt="">
                        <div class="text-right">
                            <h3 class="text-uppercase text-light mb-3">Want to be driver?</h3>
                            <p class="mb-4">Lorem justo sit sit ipsum eos lorem kasd, kasd labore</p>
                            <a class="btn btn-primary py-2 px-4" href="">Start Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 px-0">
                    <div class="px-5 bg-dark d-flex align-items-center justify-content-between" style="height: 350px;">
                        <div class="text-left">
                            <h3 class="text-uppercase text-light mb-3">Looking for a car?</h3>
                            <p class="mb-4">Lorem justo sit sit ipsum eos lorem kasd, kasd labore</p>
                            <a class="btn btn-primary py-2 px-4" href="">Start Now</a>
                        </div>
                        <img class="img-fluid flex-shrink-0 mr-n5 w-50 ml-4" src="<?= base_url(); ?>Assets/img/banner-right.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Banner End -->
    <!-- About End -->
    <?php $this->load->view('Footer'); ?>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/easing/easing.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/waypoints/waypoints.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?= base_url(); ?>Assets/js/main.js"></script>
</body>

</html>