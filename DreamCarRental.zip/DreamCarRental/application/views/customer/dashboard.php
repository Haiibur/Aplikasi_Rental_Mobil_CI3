	<!-- Carousel Start -->
	<div class="container-fluid p-0" style="margin-bottom: 90px;">
		<div id="header-carousel" class="carousel slide" data-ride="carousel">
			<div class="carousel-inner">
				<div class="carousel-item active">
					<img class="w-100" src="<?= base_url(); ?>Assets/img/carousel-1.jpg" alt="Image">
					<div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
						<div class="p-3" style="max-width: 900px;">
							<h1 class="display-1 text-white mb-md-4">Pesan sekarang dan jelajahi dunia dengan kenyamanan
								dan kebebasan penuh.</h1>
							<a href="" class="btn btn-primary py-md-3 px-md-5 mt-2">Sewa Segera</a>
						</div>
					</div>
				</div>
				<div class="carousel-item">
					<img class="w-100" src="<?= base_url(); ?>Assets/img/carousel-2.jpg" alt="Image">
					<div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
						<div class="p-3" style="max-width: 900px;">
							<h1 class="display-1 text-white mb-md-4">Kemudahan berkendara, pilihan mobil terbaik. Sewa
								mobil impianmu sekarang!</h1>
							<a href="" class="btn btn-primary py-md-3 px-md-5 mt-2">Sewa Segera</a>
						</div>
					</div>
				</div>
			</div>
			<a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
				<div class="btn btn-dark" style="width: 45px; height: 45px;">
					<span class="carousel-control-prev-icon mb-n2"></span>
				</div>
			</a>
			<a class="carousel-control-next" href="#header-carousel" data-slide="next">
				<div class="btn btn-dark" style="width: 45px; height: 45px;">
					<span class="carousel-control-next-icon mb-n2"></span>
				</div>
			</a>
		</div>
	</div>
	<!-- Carousel End -->

	<!-- Banner Start -->
	<div class="container-fluid py-5">
		<div class="container py-5">
			<div class="bg-banner py-5 px-4 text-center">
				<div class="py-5">
					<h1 class="display-1 text-uppercase text-primary mb-4">50% OFF</h1>
					<h1 class="text-uppercase text-light mb-4">Special Offer For New Members</h1>
					<p class="mb-4">Only for Sunday from 1st Jan to 30th Jan 2045</p>
					<a class="btn btn-primary mt-2 py-3 px-5" href="">Register Now</a>
				</div>
			</div>
		</div>
	</div>
	<!-- Banner End -->

	<!-- Rent A Car Start -->
	<div class="container-fluid py-5">
		<div class="container pt-5 pb-3">
			<h1 class="display-4 text-uppercase text-center mb-5">Find Your Car</h1>
			<div class="row">
				<?php foreach ($mobil as $mb) : ?>
					<div class="col-lg-4 col-md-6 mb-2">
						<div class="rent-item mb-4">
							<img class="img-fluid mb-4" src="<?php echo base_url('Assets/upload/' . $mb->gambar) ?>" alt="<?php echo $mb->merk ?>">
							<h4 class="text-uppercase mb-4"><?php echo $mb->merk ?></h4>
							<div class="d-flex justify-content-center mb-4">
								<div class="px-2">
									<span>
										<?php if ($mb->ac == '1') { ?>
											<a>AC</a>
										<?php } else { ?>
										<?php } ?>
									</span>
								</div>
								<div class="px-2">
									<span>
										<?php if ($mb->supir == '1') { ?>
											<a>SUPIR</a>
										<?php } else { ?>
										<?php } ?>
									</span>
								</div>

								<div class="px-2">
									<span>
										<?php if ($mb->mp3_player == '1') { ?>
											<a>MP3 PLAYER</a>
										<?php } else { ?>
										<?php } ?>
									</span>
								</div>

								<div class="px-2">
									<span>
										<?php if ($mb->central_lock == '1') { ?>
											<a>CENTRAL LOCK</a>
										<?php } else { ?>
										<?php } ?>
									</span>
								</div>
							</div>
							<a class="btn btn-primary px-3" href="<?= site_url('customer/Car_Liscus/Car_Booking/') . $mb->id_mobil ?>">Rp. <?php echo number_format($mb->harga, 0, ',', '.') ?>/Hari</a>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<!-- Rent A Car End -->

	<!-- Banner Start -->
	<div class="container-fluid py-5">
		<div class="container py-5">
			<div class="row mx-0">
				<div class="col-lg-6 px-0">
					<div class="px-5 bg-secondary d-flex align-items-center justify-content-between" style="height: 350px;">
						<img class="img-fluid flex-shrink-0 ml-n5 w-50 mr-4" src="<?= base_url(); ?>Assets/img/banner-left.png" alt="">
						<div class="text-right">
							<h3 class="text-uppercase text-light mb-3">Want to be driver?</h3>
							<p class="mb-4">Lorem justo sit sit ipsum eos lorem kasd, kasd labore</p>
							<a class="btn btn-primary py-2 px-4" href="">Start Now</a>
						</div>
					</div>
				</div>
				<div class="col-lg-6 px-0">
					<div class="px-5 bg-dark d-flex align-items-center justify-content-between" style="height: 350px;">
						<div class="text-left">
							<h3 class="text-uppercase text-light mb-3">Looking for a car?</h3>
							<p class="mb-4">Lorem justo sit sit ipsum eos lorem kasd, kasd labore</p>
							<a class="btn btn-primary py-2 px-4" href="">Start Now</a>
						</div>
						<img class="img-fluid flex-shrink-0 mr-n5 w-50 ml-4" src="<?= base_url(); ?>Assets/img/banner-right.png" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Banner End -->

	<!-- Testimonial Start -->
	<div class="container-fluid py-5">
		<div class="container py-5">
			<h1 class="display-4 text-uppercase text-center mb-5">TESTIMONI PENGGUNA</h1>
			<div class="owl-carousel testimonial-carousel">
				<div class="testimonial-item d-flex flex-column justify-content-center px-4">
					<div class="d-flex align-items-center justify-content-between mb-3">
						<img class="img-fluid ml-n4" src="<?= base_url(); ?>Assets/img/testimonial-1.jpg" alt="">
						<h1 class="display-2 text-white m-0 fa fa-quote-right"></h1>
					</div>
					<h4 class="text-uppercase mb-2">Client Name</h4>
					<i class="mb-2">Profession</i>
					<p class="m-0">Terima kasih atas layanan yang luar biasa! Rental mobil ini sangat memuaskan dan
						mobil yang disewakan dalam kondisi prima. Proses pemesanan mudah dan cepat, serta staf yang
						sangat ramah dan membantu. Pengalaman menyenangkan untuk liburan kami. Akan kembali menyewa
						mobil di sini untuk perjalanan berikutnya. Rekomendasi tinggi</p>
				</div>
				<div class="testimonial-item d-flex flex-column justify-content-center px-4">
					<div class="d-flex align-items-center justify-content-between mb-3">
						<img class="img-fluid ml-n4" src="<?= base_url(); ?>Assets/img/testimonial-2.jpg" alt="">
						<h1 class="display-2 text-white m-0 fa fa-quote-right"></h1>
					</div>
					<h4 class="text-uppercase mb-2">Client Name</h4>
					<i class="mb-2">Profession</i>
					<p class="m-0">Saya sangat puas dengan layanan rental mobil ini. Mobil yang disediakan sangat nyaman
						dan bersih. Harga sewa juga terjangkau dan proses pemesanan online sangat mudah. Tim layanan
						pelanggan sangat responsif dan membantu dengan segala pertanyaan saya. Terima kasih telah
						membuat perjalanan saya lebih lancar dan menyenangkan</p>
				</div>
				<div class="testimonial-item d-flex flex-column justify-content-center px-4">
					<div class="d-flex align-items-center justify-content-between mb-3">
						<img class="img-fluid ml-n4" src="<?= base_url(); ?>Assets/img/testimonial-3.jpg" alt="">
						<h1 class="display-2 text-white m-0 fa fa-quote-right"></h1>
					</div>
					<h4 class="text-uppercase mb-2">Client Name</h4>
					<i class="mb-2">Profession</i>
					<p class="m-0">Pengalaman menyewa mobil terbaik yang pernah saya miliki! Pilihan mobil yang lengkap
						dan kondisi mobil sangat baik. Semua proses dari awal hingga akhir sangat profesional dan
						efisien. Tim di sini sangat ramah dan membantu mengurus semua kebutuhan kami. Sangat
						merekomendasikan untuk semua orang yang mencari layanan rental mobil yang berkualitas.</p>
				</div>
				<div class="testimonial-item d-flex flex-column justify-content-center px-4">
					<div class="d-flex align-items-center justify-content-between mb-3">
						<img class="img-fluid ml-n4" src="<?= base_url(); ?>Assets/img/testimonial-4.jpg" alt="">
						<h1 class="display-2 text-white m-0 fa fa-quote-right"></h1>
					</div>
					<h4 class="text-uppercase mb-2">Client Name</h4>
					<i class="mb-2">Profession</i>
					<p class="m-0">Wow, saya benar-benar terkesan dengan layanan yang diberikan oleh rental mobil ini.
						Proses pemesanan sangat cepat dan mudah, dan mobil yang kami sewa dalam kondisi prima. Layanan
						pelanggan sangat responsif dan membantu selama perjalanan kami. Harga juga sangat wajar untuk
						kualitas yang kami dapatkan. Akan kembali untuk menyewa di masa depan!</p>
				</div>
				<div class="testimonial-item d-flex flex-column justify-content-center px-4">
					<div class="d-flex align-items-center justify-content-between mb-3">
						<img class="img-fluid ml-n4" src="<?= base_url(); ?>Assets/img/testimonial-4.jpg" alt="">
						<h1 class="display-2 text-white m-0 fa fa-quote-right"></h1>
					</div>
					<h4 class="text-uppercase mb-2">Client Name</h4>
					<i class="mb-2">Profession</i>
					<p class="m-0">Terima kasih atas layanan yang memuaskan! Rental mobil ini memberikan pengalaman yang
						menyenangkan bagi keluarga kami. Mobil yang kami sewa nyaman dan dilengkapi dengan semua fitur
						yang kami butuhkan. Tim di sini sangat profesional dan membantu kami dengan semua pertanyaan
						kami. Sangat senang kami memilih rental mobil ini.</p>
				</div>
				<div class="testimonial-item d-flex flex-column justify-content-center px-4">
					<div class="d-flex align-items-center justify-content-between mb-3">
						<img class="img-fluid ml-n4" src="<?= base_url(); ?>Assets/img/testimonial-4.jpg" alt="">
						<h1 class="display-2 text-white m-0 fa fa-quote-right"></h1>
					</div>
					<h4 class="text-uppercase mb-2">Client Name</h4>
					<i class="mb-2">Profession</i>
					<p class="m-0">Suatu keputusan yang tepat untuk menyewa mobil di sini! Mobil yang kami pilih dalam
						kondisi yang sangat baik dan harga sewanya sangat bersaing. Proses penyewaan sangat cepat dan
						mudah, serta staf yang sangat ramah dan membantu. Pengalaman menyenangkan secara keseluruhan.
						Akan merekomendasikan kepada teman-teman saya yang membutuhkan layanan rental mobil.</p>
				</div>
			</div>
		</div>
	</div>
	<!-- Testimonial End -->


	<!-- Contact Start -->
	<div class="container-fluid py-5">
		<div class="container pt-5 pb-3">
			<h1 class="display-4 text-uppercase text-center mb-5">Contact Us</h1>
			<div class="row">
				<div class="col-lg-7 mb-2">
					<div class="contact-form bg-light mb-4" style="padding: 30px;">
						<form>
							<div class="row">
								<div class="col-6 form-group">
									<input type="text" class="form-control p-4" placeholder="Your Name" required="required">
								</div>
								<div class="col-6 form-group">
									<input type="email" class="form-control p-4" placeholder="Your Email" required="required">
								</div>
							</div>
							<div class="form-group">
								<input type="text" class="form-control p-4" placeholder="Subject" required="required">
							</div>
							<div class="form-group">
								<textarea class="form-control py-3 px-4" rows="5" placeholder="Message" required="required"></textarea>
							</div>
							<div>
								<button class="btn btn-primary py-3 px-5" type="submit">Send Message</button>
							</div>
						</form>
					</div>
				</div>
				<div class="col-lg-5 mb-2">
					<div class="bg-secondary d-flex flex-column justify-content-center px-5 mb-4" style="height: 435px;">
						<div class="d-flex mb-3">
							<i class="fa fa-2x fa-map-marker-alt text-primary flex-shrink-0 mr-3"></i>
							<div class="mt-n1">
								<h5 class="text-light">Head Office</h5>
								<p>123 Street, New York, USA</p>
							</div>
						</div>
						<div class="d-flex mb-3">
							<i class="fa fa-2x fa-map-marker-alt text-primary flex-shrink-0 mr-3"></i>
							<div class="mt-n1">
								<h5 class="text-light">Branch Office</h5>
								<p>123 Street, New York, USA</p>
							</div>
						</div>
						<div class="d-flex mb-3">
							<i class="fa fa-2x fa-envelope-open text-primary flex-shrink-0 mr-3"></i>
							<div class="mt-n1">
								<h5 class="text-light">Customer Service</h5>
								<p>customer@example.com</p>
							</div>
						</div>
						<div class="d-flex">
							<i class="fa fa-2x fa-envelope-open text-primary flex-shrink-0 mr-3"></i>
							<div class="mt-n1">
								<h5 class="text-light">Return & Refund</h5>
								<p class="m-0">refund@example.com</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Contact End -->