<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Dream Car Rental</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="<?= base_url(); ?>Assets/<?= base_url(); ?>Assets/img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Rubik&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= base_url(); ?>Assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>Assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?= base_url(); ?>Assets/css/style.css" rel="stylesheet">
</head>

<body>
    <?php $this->load->view('Header'); ?>

    <!-- Contact Start -->
    <div class="container-fluid py-5">
        <div class="container pt-5 pb-3">
            <h1 class="display-4 text-uppercase text-center mb-5">REGISTRASI</h1>
            <form action="<?= site_url('Register') ?>" method="post">
                <div class="row">
                    <div class="col-lg-6 mb-2">
                        <div class="contact-form bg-light mb-4" style="padding: 30px;">
                            <div class="row">
                                <div class="form-group col-6">
                                    <label for="nama">Nama</label>
                                    <input id="nama" type="text" class="form-control" name="nama" autofocus>
                                    <?php echo form_error('nama', '<div class="text-small text-danger">', '</div>') ?>
                                </div>
                                <div class="form-group col-6">
                                    <label>No. KTP</label>
                                    <input type="text" name="no_ktp" class="form-control">
                                    <?php echo form_error('no_ktp', '<div class="text-small text-danger">', '</div>') ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="alamat">Alamat</label>
                                <input id="alamat" type="text" class="form-control" name="alamat">
                                <?php echo form_error('alamat', '<div class="text-small text-danger">', '</div>') ?>
                                <div class="invalid-feedback">
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-6">
                                    <label for="gender" class="d-block">Gender</label>
                                    <select class="form-control" name="gender">
                                        <option value="">-- Pilih gender --</option>
                                        <option value="Laki-laki">Laki-laki</option>
                                        <option value="Perempuan">Perempuan</option>
                                    </select>
                                    <?php echo form_error('gender', '<div class="text-small text-danger">', '</div>') ?>
                                </div>
                                <div class="form-group col-6">
                                    <label for="no_telp" class="d-block">No. Telepon</label>
                                    <input id="no_telp" type="text" class="form-control" name="no_telp">
                                    <?php echo form_error('no_telp', '<div class="text-small text-danger">', '</div>') ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-6">
                                    <label for="username">Username</label>
                                    <input id="username" type="text" class="form-control" name="username">
                                    <?php echo form_error('username', '<div class="text-small text-danger">', '</div>') ?>
                                </div>
                                <div class="form-group col-6">
                                    <label>Password</label>
                                    <input type="password" name="password" class="form-control">
                                    <?php echo form_error('password', '<div class="text-small text-danger">', '</div>') ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-lg btn-block">
                                    Register
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Contact End -->

    <?php $this->load->view('Footer'); ?>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/easing/easing.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/waypoints/waypoints.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="<?= base_url(); ?>Assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="<?= base_url(); ?>Assets/js/main.js"></script>
</body>

</html>