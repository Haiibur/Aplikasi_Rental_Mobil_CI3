	<!-- Topbar Start -->
	<div class="container-fluid bg-dark py-3 px-lg-5 d-none d-lg-block">
		<div class="row">
			<div class="col-md-6 text-center text-lg-left mb-2 mb-lg-0">
				<div class="d-inline-flex align-items-center">
					<a class="text-body pr-3" href=""><i class="fa fa-phone-alt mr-2"></i>+012 345 6789</a>
					<span class="text-body">|</span>
					<a class="text-body px-3" href=""><i class="fa fa-envelope mr-2"></i>info@example.com</a>
				</div>
			</div>
			<div class="col-md-6 text-center text-lg-right">
				<div class="d-inline-flex align-items-center">
					<a class="text-body px-3" href="">
						<i class="fab fa-facebook-f"></i>
					</a>
					<a class="text-body px-3" href="">
						<i class="fab fa-twitter"></i>
					</a>
					<a class="text-body px-3" href="">
						<i class="fab fa-linkedin-in"></i>
					</a>
					<a class="text-body px-3" href="">
						<i class="fab fa-instagram"></i>
					</a>
					<a class="text-body pl-3" href="">
						<i class="fab fa-youtube"></i>
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- Topbar End -->

	<!-- Navbar Start -->
	<div class="container-fluid position-relative nav-bar p-0">
		<div class="position-relative px-lg-5" style="z-index: 9;">
			<nav class="navbar navbar-expand-lg bg-secondary navbar-dark py-3 py-lg-0 pl-3 pl-lg-5">
				<a href="" class="navbar-brand">
					<h1 class="text-uppercase text-primary mb-1">Dream Car Rental</h1>
				</a>
				<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse justify-content-between px-3" id="navbarCollapse">
					<div class="navbar-nav ml-auto py-0">
						<a href="<?= base_url() ?>" class="nav-item nav-link active">Home</a>
						<a href="<?= site_url('Welcome/About')  ?>" class="nav-item nav-link">About</a>
						<a href="<?= site_url('Welcome/Car_List')  ?>" class="nav-item nav-link">Car Listing</a>
						<a href="<?= site_url('Welcome/Register')  ?>" class="nav-item nav-link">Register</a>
						<a href="<?= site_url('Welcome/Login')  ?>" class="nav-item nav-link">Login</a>
					</div>
				</div>
			</nav>
		</div>
	</div>
	<!-- Navbar End -->

	<!-- Search Start -->
	<div class="container-fluid bg-white pt-3 px-lg-5">
		<div class="row mx-n2">
			<div class="col-xl-2 col-lg-4 col-md-6 px-2">
			</div>
			<div class="col-xl-2 col-lg-4 col-md-6 px-2">
			</div>
			<div class="col-xl-2 col-lg-4 col-md-6 px-2">
				<select class="custom-select px-4 mb-3" style="height: 50px;">
					<option disabled selected>--- Select A Car ---</option>
					<?php
					$mobil = $this->db->query("SELECT * FROM mobil mb, type tp WHERE mb.kode_type=tp.kode_type")->result();
					foreach ($mobil as $mb) : ?>
						<option value="1"><?php echo $mb->merk ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="col-xl-2 col-lg-4 col-md-6 px-2">
				<div class="date mb-3" id="date" data-target-input="nearest">
					<input type="text" style="height: 50px;" class="form-control p-4 datetimepicker-input" placeholder="--- Pilih Tanggal ---" data-target="#date" data-toggle="datetimepicker" />
				</div>
			</div>
			<div class="col-xl-2 col-lg-4 col-md-6 px-2">
				<div class="time mb-3" id="time" data-target-input="nearest">
					<input style="height: 50px;" type="text" class="form-control p-4 datetimepicker-input" placeholder="--- Pilih Jam ---" data-target="#time" data-toggle="datetimepicker" />
				</div>
			</div>
			<div class="col-xl-2 col-lg-4 col-md-6 px-2">
				<a href="<?= site_url('Welcome/Car_List')  ?>" class="btn btn-primary btn-block mb-3" type="submit" style="height: 50px;">Cari</a>
			</div>
		</div>
	</div>
	<!-- Search End -->