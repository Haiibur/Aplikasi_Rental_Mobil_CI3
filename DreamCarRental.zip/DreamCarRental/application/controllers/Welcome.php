<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
	}

	public function index()
	{
		$data['mobil'] = $this->db->query("SELECT * FROM mobil mb, type tp WHERE mb.kode_type=tp.kode_type")->result();
		$data['rental'] = $this->db->query("SELECT nama_rental FROM customer WHERE nama_rental != ''")->result();
		$data['type'] = $this->rental_model->get_data('type')->result();
		$data['total_mobil'] = $this->db->query("SELECT * FROM mobil WHERE status = '1'")->num_rows() - 1;
		$data['total_customer'] = $this->db->query("SELECT * FROM customer WHERE role_id = '2'")->num_rows() - 1;
		$data['total_rental'] = $this->db->query("SELECT * FROM customer WHERE role_id = '3'")->num_rows() - 1;

		$this->load->view('welcome_message', $data);
	}

	public function About()
	{
		$this->load->view('About');
	}

	public function Car_List()
	{
		$data['mobil'] = $this->db->query("SELECT * FROM mobil mb, type tp WHERE mb.kode_type=tp.kode_type")->result();

		$data['rental'] = $this->db->query("SELECT nama_rental FROM customer WHERE nama_rental != ''")->result();

		$data['type'] = $this->rental_model->get_data('type')->result();
		$data['total_mobil'] = $this->db->query("SELECT * FROM mobil WHERE status = '1'")->num_rows() - 1;
		$data['total_customer'] = $this->db->query("SELECT * FROM customer WHERE role_id = '2'")->num_rows() - 1;
		$data['total_rental'] = $this->db->query("SELECT * FROM customer WHERE role_id = '3'")->num_rows() - 1;
		$this->load->view('CarLis', $data);
	}

	public function Car_Detail($id)
	{
		$data['mobil'] = $this->db->query("SELECT * FROM mobil mb, type tp WHERE mb.kode_type=tp.kode_type")->result();

		$data['rental'] = $this->db->query("SELECT nama_rental FROM customer WHERE nama_rental != ''")->result();

		$data['type'] = $this->rental_model->get_data('type')->result();
		$data['total_mobil'] = $this->db->query("SELECT * FROM mobil WHERE status = '1'")->num_rows() - 1;
		$data['total_customer'] = $this->db->query("SELECT * FROM customer WHERE role_id = '2'")->num_rows() - 1;
		$data['total_rental'] = $this->db->query("SELECT * FROM customer WHERE role_id = '3'")->num_rows() - 1;

		$data['detail'] = $this->rental_model->ambil_id_mobil($id);
		$data['rental'] = $this->db->query("SELECT * FROM customer cs, mobil mb WHERE mb.nama_rental = cs.nama_rental AND mb.id_mobil = '$id'")->result();

		$this->load->view('CarDet', $data);
	}

	public function Car_Booking()
	{
		$this->load->view('CarBok');
	}

	public function Register()
	{
		$this->load->view('Regis');
	}

	public function Login()
	{
		$this->load->view('Login');
	}
}
